use Test;
BEGIN { plan tests => 1 };
use FCGI;
ok(1); # If we made it this far, we're ok.
